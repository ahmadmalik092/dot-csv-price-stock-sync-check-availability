jQuery( document ).ready(function() {
    //alert( "ready!" );
    jQuery('.dot_update_stock_manner').change(
        function(){
            jQuery('div.dot_time_box').addClass('dot_hidden');
            var nam = jQuery(this).val();
            if (jQuery(this).is(':checked')) {
                jQuery('div.dot_'+nam+'_box').removeClass('dot_hidden');
            }
        });

    //alert( "ready!" );
    jQuery('.dot_us_match').change(
        function(){
            jQuery('.dot_us_match_box').addClass('dot_hidden');
            var nam = jQuery(this).val();
            if (jQuery(this).is(':checked')) {
                jQuery('.dot_us_'+nam+'_box').removeClass('dot_hidden');
            }
        });
});

jQuery('#dot_settings_save').on('click',function(event){
    event.preventDefault();
    jQuery( '#dot_status' ).html( 'saving.... (wait)' );
    
    var dot_landingpages_url = jQuery('#dot_landingpages_url').val();
    var dot_addresses_url = jQuery('#dot_addresses_url').val();
    var dot_form_id = jQuery('#dot_form_id').val();

    // var dot_us_prices_col = jQuery('#dot_us_prices_col').val();
    // var dot_us_stock_col = jQuery('#dot_us_stock_col').val();
    // var dot_us_start_row = jQuery('#dot_us_start_row').val();

    //validate stock_file_url is not empty
    if(!dot_landingpages_url || !dot_addresses_url){
        jQuery( '#dot_status' ).html( 'One of the file is invalid.' );
        return;
    }else{
        var dataa = {
            dot_landingpages_url: dot_landingpages_url,
            dot_addresses_url: dot_addresses_url,
            dot_form_id: dot_form_id,
            action: 'dot_save_meta'
        };   
        jQuery.post( ajax_url, dataa, function(response) {  
            console.log(response);
            jQuery( '#dot_status' ).html( response.message );
        });
    }
    
});

jQuery('#dot_cu_settings_save').on('click',function(event){
    event.preventDefault();
    jQuery( '#dot_status' ).html( 'saving.... (wait)' );
    
    var dot_us_file_url = jQuery('#dot_us_file_url').val();
    var dot_us_match_option = jQuery('input.dot_us_match:checked').val();
    console.log('match: '+dot_us_match_option);
    switch(dot_us_match_option){
        case 'custom':
            var dot_us_match_product_attr = jQuery('#dot_us_match_custom_attr').val();
            var dot_us_match_csv_col = jQuery('#dot_us_match_custom_col').val();
            break;
        case 'pid':
            var dot_us_match_product_attr = 'pid';
            var dot_us_match_csv_col = jQuery('#dot_us_match_pid_col').val();
            break;
        case 'sku':
            var dot_us_match_product_attr = 'sku';
            var dot_us_match_csv_col = jQuery('#dot_us_match_sku_col').val();
            break;
        default:
            break;
    }
    var dot_us_start_row = jQuery('#dot_us_start_row').val();

    var dot_us_file_url = jQuery('#dot_us_file_url').val();
    var dot_read_file_method = jQuery('input.dot_read_file_method:checked').val();

    
       

    //validate stock_file_url is not empty
    if(!dot_us_file_url){
        jQuery( '#dot_status' ).html( 'invalid csv file' );
        return;
    }

    var duration = jQuery('input.dot_update_stock_manner:checked').val();
    if(duration == 'never'){
        var duration_value = 9999;
    }
    else{
        var duration_value = jQuery('input#dot_update_stock_every_x_'+duration).val();
    }

    //validate duration_value is greater than 1
    if(duration_value >= 1){
        
        var dataa = {
            dot_us_file_url: dot_us_file_url,
            dot_us_manner: duration,
            dot_us_duration: duration_value,
            dot_us_match_product_attr: dot_us_match_product_attr,
            dot_us_match_csv_col: dot_us_match_csv_col,
            dot_us_start_row: dot_us_start_row,
            dot_us_match_option: dot_us_match_option,
            dot_read_file_method: dot_read_file_method,
            action: 'dot_save_cu_meta'
        };
        var dot_cu_custom_field = jQuery('.dot_cu_custom_field');
        var dot_cu_custom_fields = {};
        jQuery.each( dot_cu_custom_field, function( i, field ) {
            var vall = jQuery(field).val();
            if(vall){
                dot_cu_custom_fields[jQuery(field).attr('id')] = vall;
            }
        });
        dataa['dot_cu_custom_fields'] = dot_cu_custom_fields;
        console.log(dataa);    
        jQuery.post( ajax_url, dataa, function(response) {  
            console.log(response);
            jQuery( '#dot_status' ).html( response.message );
        });

    }else{
        // combine data and send to ajax for update meta option
        console.log('duration_value is less than 1');
    }
    
});

//update products now
jQuery('#dot_cu_update_products_now').on('click',function(event){
    event.preventDefault();
    jQuery( '#dot_status' ).html( 'updating products.... (wait)' );
    

    //validate duration_value is greater than 1
    if(true){
        
        var dataa = {
            action: 'dot_create_update_products'
        }; 
        jQuery.post( ajax_url, dataa, function(response) {  
            console.log(response);
            jQuery( '#dot_status' ).html( response.message );
        });

    }else{
        // combine data and send to ajax for update meta option
        console.log('error updating products');
    }
    
});
