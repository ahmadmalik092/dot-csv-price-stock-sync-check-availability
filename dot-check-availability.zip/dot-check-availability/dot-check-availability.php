<?php
/**
  * Plugin Name: Dot Check Availability
 * Description: Integrate a check functionality on a custom form and validate against a csv file. 
 * Version:     1.0.0
 * Author:      M. Ahmad Malik
 * Author URI:  https://www.upwork.com/freelancers/~018baa86584a55223c
 * Text Domain: dot-check-availability
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Register a custom menu page.
 */
function wpdocs_register_my_custom_menu_page() {
    add_menu_page(
        __( 'Availability Settings', 'dot-check-availability' ), //page title
        'Availability', //menu title
        'manage_options', //capability
        'dot-check-availability/dot-update-products-admin.php', //menu slug
        '', //callback function (render function)
        //plugins_url( 'dot-update-products/assets/images/icon.png' ), //icon url
        6 //position
    );
}
add_action( 'admin_menu', 'wpdocs_register_my_custom_menu_page' );


function add_script_to_menu_page()
{
    // $pagenow, is a global variable referring to the filename of the current page, 
    // such as ‘admin.php’, ‘post-new.php’
    global $pagenow;
    
    if ($pagenow != 'admin.php') {
        return;
    }
    // loading css
    wp_register_style( 'dot-css', plugins_url( 'css/dot_style.css' , __FILE__ ), false, '1.0.0' );
    wp_enqueue_style( 'dot-css' );
     
    // loading js
    wp_register_script( 'dot-js', plugins_url( 'js/dot_script.js' , __FILE__ ), array('jquery-core'), false, true );
    wp_enqueue_script( 'dot-js' );
}
 
add_action( 'admin_enqueue_scripts', 'add_script_to_menu_page' );


function my_load_scripts($hook) {
 
    // create my own version codes
    wp_enqueue_script( 'dot_front_js', plugins_url( 'js/dot_script_front1.js', __FILE__ ), array('jquery-core'), false,true );
}
add_action('wp_enqueue_scripts', 'my_load_scripts');

function ajax_url_js() {
    echo '
        <script type="text/javascript">
        var ajax_url = "'.admin_url('admin-ajax.php').'";
        </script>
    ';
}
// Add hook for front-end <head></head>
add_action( 'wp_head', 'ajax_url_js' );

// ajax function that gets called to save meta options from dot settings for update stock and prices
add_action("wp_ajax_dot_save_meta", "dot_save_meta");
add_action("wp_ajax_nopriv_dot_save_meta", "dot_save_meta");

function dot_save_meta() {
    if ( isset( $_POST['dot_landingpages_url'] ) &&  isset( $_POST['dot_addresses_url'] ) ) {
        $dot_landingpages_url  = $_POST['dot_landingpages_url'];
        $dot_addresses_url  = $_POST['dot_addresses_url'];
        $dot_form_id  = $_POST['dot_form_id'];
        
        if ( !empty( $dot_landingpages_url ) && !empty( $dot_addresses_url ) ) {
            $dot_sp_update_options = array(
                'dot_landingpages_url' => $dot_landingpages_url,
                'dot_addresses_url' => $dot_addresses_url,
                'dot_form_id' => $dot_form_id,
            );
            $status = update_option('dot_cu_update_options', json_encode($dot_sp_update_options));
        }
        $return = array( 'message' => "Settings are saved!!!" );
        wp_send_json( $return );
    }else{
        $return = array( 'message' => "Error: Make sure all field are filled correctly!!!" );
        wp_send_json( $return );
    }
    
}


//checking availability
add_action("wp_ajax_dot_check_availability", "dot_check_availability");
add_action("wp_ajax_nopriv_dot_check_availability", "dot_check_availability");

function dot_check_availability() {
    if ( isset( $_POST['dot_street'] ) &&  isset( $_POST['dot_house'] ) &&  isset( $_POST['dot_zip'] ) &&  isset( $_POST['dot_town'] ) ) {
        $dot_street  = strtolower($_POST['dot_street']);
        $dot_house  = strtolower($_POST['dot_house']);
        $dot_zip  = strtolower($_POST['dot_zip']);
        $dot_town  = strtolower($_POST['dot_town']);

        $is_available = false;

        $dot_options = get_option('dot_cu_update_options');
        if($dot_options)
            $dot_options = json_decode($dot_options, true);

        
        $dot_landingpages_url = isset($dot_options ['dot_landingpages_url']) ? $dot_options ['dot_landingpages_url']: '';
        $dot_addresses_url = isset($dot_options ['dot_addresses_url']) ? $dot_options ['dot_addresses_url']: ''; 

        if(isset($dot_addresses_url)){
            $csvFile = file($dot_addresses_url);
            if(!$csvFile){
                exit;
            }

            $rows = [];
            foreach ($csvFile as $line) {
                $rows[] = str_getcsv($line,';');
            }

            foreach($rows as $row){
                //dot_print($row);
                if(strtolower($row[0]) == $dot_street){
                    if(strtolower($row[1]) == $dot_house){
                        if(strtolower($row[2]) == $dot_zip){
                            if(strtolower($row[3]) == $dot_town){
                                $is_available = true;
                                $area_id = $row[4];
                                break;
                            }else{
                                $is_available = false;
                            }
                        }else{
                            $is_available = false;
                        }
                    }else{
                        $is_available = false;
                    }
                }else{
                    $is_available = false;
                } 
            }
            if($is_available){
                $landingFile = file($dot_landingpages_url);
                    if(!$landingFile){
                        $return = array( 'message' => "Area Found! Please Contact Our Team for more information.!!!", 'found_status' => '2' );
                        wp_send_json( $return );
                    }

                    $rows = [];
                    $areas = [];
                    $count = 0;
                    foreach ($landingFile as $line) {
                        $row = str_getcsv($line,';');
                        if($count>0){
                            $areas[$row[0]] = $row[1];
                        }
                        $count++;
                    }
                    //dot_print($areas);
                    if(isset($areas[$area_id])){
                        $url = site_url( $areas[$area_id], 'https' );
                        $return = array( 'message' => "Area Found. Redirecting you to relevant page.", 'dot_redirect' => $url, 'found_status' => '1' );
                        wp_send_json( $return );
                    }else{
                        $return = array( 'message' => "Sorry! We're currently not available in your area. Thanks!", 'found_status' => '0' );
                        wp_send_json( $return );
                    }

            }else{
                $return = array( 'message' => "We're currently not available in your area. Thanks!", 'found_status' => '0' );
                wp_send_json( $return );
            }
        }
        
    }else{
        $return = array( 'message' => "Error: Make sure all field are filled correctly!!!", 'found_status' => '0' );
        wp_send_json( $return );
    }
    
}