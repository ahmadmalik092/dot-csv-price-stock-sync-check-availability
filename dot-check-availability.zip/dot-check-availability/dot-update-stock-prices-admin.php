<?php
//add dot_stock_update_last and dot_stock_update_next fields


// {} = []
// get an option
$dot_options = get_option('dot_sp_update_options');
if($dot_options)
    $dot_options = json_decode($dot_options, true);

$dot_us_file_url = isset($dot_options ['dot_us_file_url']) ? $dot_options ['dot_us_file_url']: '';
$dot_us_duration = isset($dot_options ['dot_us_duration']) ? $dot_options ['dot_us_duration']: '';
$dot_us_manner = isset($dot_options['dot_us_manner']) ? $dot_options['dot_us_manner']: '';

$dot_us_match_option = isset($dot_options['dot_us_match_option']) ? $dot_options['dot_us_match_option']: '';
$dot_us_match_product_attr = isset($dot_options['dot_us_match_product_attr']) ? $dot_options['dot_us_match_product_attr']: '';
$dot_us_match_csv_col = isset($dot_options['dot_us_match_csv_col']) ? $dot_options['dot_us_match_csv_col']: '';

$dot_us_stock_col = isset($dot_options['dot_us_stock_col']) ? $dot_options['dot_us_stock_col']: '';
$dot_us_prices_col = isset($dot_options['dot_us_prices_col']) ? $dot_options['dot_us_prices_col']: '';
$dot_us_start_row = isset($dot_options['dot_us_start_row']) ? $dot_options['dot_us_start_row']: '';

$never = false;
$minutely = false;
$hourly = false;
$daily = false;

switch($dot_us_manner){
    case 'minutely':
        $minutely = true;
        break;
    case 'hourly':
        $hourly = true;
        break;
    case 'daily':
        $daily = true;
        break;
    default:
        $never = true;
        break;
}

$custom = false;
$sku = false;
$pid = false;

switch($dot_us_match_option){
    case 'custom':
        $custom = true;
        break;
    case 'pid':
        $pid = true;
        break;
    case 'sku':
        $sku = true;
        break;
    default:
        $custom = true;
        break;
}

$dot_next_sync = get_option('dot_next_sync');
$dot_last_sync = get_option('dot_last_sync');
?>


<script type="text/javascript">
    var ajax_url = "<?php echo admin_url('admin-ajax.php'); ?>";
</script>

<h2>Update Stock & Prices</h2>
<p>Configure How do you want to update product stock and prices...</p>
<p><strong>Last Update: </strong><?php echo $dot_last_sync ? $dot_last_sync: 'Unknown!' ?></p>
<p>
    <strong>Next Update: </strong><?php echo $dot_next_sync ? $dot_next_sync: 'Not Set!' ?>
</p>
<p>
    <strong>Current Time: </strong><?php echo date( 'H:i:s Y-m-d ', strtotime( current_time('mysql') ) ); ?></p>
<p>


<hr>
<h3>File URL</h3>
<input type="url" id="dot_us_file_url" class="dot_update_stock" name="dot_us_file_url" value="<?php echo $dot_us_file_url; ?>">
<br><br>
<hr>

<!-- Settings: manner and duration -->
<div>
    <h3>Prices & Stock Update Settings</h3>

    <input type="radio" name="dot_update_stock_duration" value="never" id="dot_update_stock_never" class="dot_update_stock_manner" <?php echo ($never) ? 'checked': '' ?>>
    <label for="dot_update_stock_never">Don't Update Stock and Prices</label>
    <br>

    <input type="radio" name="dot_update_stock_duration" value="minutely" id="dot_update_stock_minutely" class="dot_update_stock_manner" <?php echo ($minutely) ? 'checked': '' ?>>
    <label for="dot_update_stock_minutely">Update Stock and Prices Minutely</label>
    <br>
    <div class="dot_time_box dot_minutely_box <?php echo ($minutely) ? '': 'dot_hidden'?>">
        
        Update products stock & price every
        <input type="number" id="dot_update_stock_every_x_minutely" class="dot_update_stock" name="dot_update_stock_mins" value="30">
        minutes
    </div>

    <input type="radio" name="dot_update_stock_duration" value="hourly" id="dot_update_stock_hourly" class="dot_update_stock_manner" <?php echo ($hourly) ? 'checked': '' ?>>
    <label for="dot_update_stock_hourly">Update Stock and Prices Hourly</label>
    <br>
    <div class="dot_time_box dot_hourly_box <?php echo ($hourly) ? '': 'dot_hidden'?>">
        
        Update products stock & price every
        <input type="number" id="dot_update_stock_every_x_hourly" class="dot_update_stock" name="dot_update_stock_hours" value="6">
        hours
    </div>

    <input type="radio" name="dot_update_stock_duration" value="daily" id="dot_update_stock_daily" class="dot_update_stock_manner" <?php echo ($daily) ? 'checked': '' ?>>
    <label for="dot_update_stock_daily">Update Stock and Prices After Every X Days</label>
    <br>
    <div class="dot_time_box dot_daily_box <?php echo ($daily) ? '': 'dot_hidden'?>">
        
        Update products stock & price every x 
        <input type="number" id="dot_update_stock_every_x_daily" class="dot_update_stock" name="dot_update_stock_days" value="3">
        days
    </div>
</div>
<hr>

<!-- Settings columns and keys -->
<div>
    <h3>Matching Columns Settings</h3>
    <p>Select, How will you match products with records in csv file?</p>

    <!-- match product attr with a csv column -->
    <input type="radio" name="dot_us_match_option" value="custom" id="dot_us_match_custom" class="dot_us_match" <?php echo ($custom) ? 'checked': '' ?>>
    <label for="dot_us_match_custom">Match Product Custom Attribute with a Column</label>
    <br>
    <div class="dot_us_match_box dot_us_custom_box <?php echo ($custom) ? '': 'dot_hidden'?>"">
        <table>
            <tr>
                <td>Match Product Custom Attribute (Field Name)</td>
                <td><input type="text" id="dot_us_match_custom_attr" class="dot_update_stock" name="dot_us_match_custom_attr" value="_dot_product_ean_field"></td>
            </tr>
            <tr>
                <td>with CSV column # </td>
                <td><input type="number" id="dot_us_match_custom_col" class="dot_update_stock" name="dot_us_match_custom_col" value="4"></td>
            </tr>
        </table>
        

    </div>
    <br>

    <!-- match product id with a csv column -->
    <input type="radio" name="dot_us_match_option" value="pid" id="dot_us_match_pid" class="dot_us_match" <?php echo ($pid) ? 'checked': '' ?>>
    <label for="dot_us_match_pid">Match Product ID with a Column</label>
    <br>
    <div class="dot_us_match_box dot_us_pid_box <?php echo ($pid) ? '': 'dot_hidden'?>"">
        
        Match Product ID with CSV column # 
        <input type="number" id="dot_us_match_pid_col" class="dot_update_stock" name="dot_us_match_pid_col" value="4">
        <br>

    </div>
    <br>

    <!-- match product sku with a csv column -->
    <input type="radio" name="dot_us_match_option" value="sku" id="dot_us_match_sku" class="dot_us_match" <?php echo ($sku) ? 'checked': '' ?>>
    <label for="dot_us_match_sku">Match Product SKU with a Column</label>
    <br>
    <div class="dot_us_match_box dot_us_sku_box <?php echo ($sku) ? '': 'dot_hidden'?>"">
        
        Match Product sku with CSV column # 
        <input type="number" id="dot_us_match_sku_col" class="dot_update_stock" name="dot_us_match_sku_col" value="4">
        <br>

    </div>

</div>
<hr>

<h3>Select Price & Stock Columns?</h3>
<table>
        <tr>
            <td>
                <label style='width: 100px;'>Price Column #</label>
            </td>
            <td>
                <input type="number" id="dot_us_prices_col" class="dot_us_prices_col" name="dot_us_prices_col" value="<?php echo $dot_us_prices_col; ?>"> 
            </td>
            <td>
                <small>- e.g. 2 
                <br> which column in csv contain product prices?</small>
            </td>
        </tr>
        <tr>
            <td>
                <label style='width: 100px;'>Stock Column #</label>
            </td>
            <td>
                <input type="number" id="dot_us_stock_col" class="dot_us_stock_col" name="dot_us_stock_col" value="<?php echo $dot_us_stock_col; ?>"> 
            </td>
            <td>
                <small>- e.g. 3
                <br>which column in csv contain product stock?</small>
            </td>
        </tr>
        <tr>
            <td>
                <label style='width: 100px;'>Start Row #</label>
            </td>
            <td>
                <input type="text" id="dot_us_start_row" class="dot_us_start_row" name="dot_us_start_row" value="<?php echo $dot_us_start_row; ?>"> 
            </td>
            <td>
                
                <small>- e.g. 3
                <br>Row that contains the first record. It should be the column names.</small>
            </td>
        </tr>
        
</table>
<hr>
<br>
<button id="dot_update_stock_settings_save"> Save Settings </button>
<br>
<br>
<p id='dot_status'></p>
<br><br>
<hr>

<?php
if(isset($dot_us_file_url)){
    $csvFile = file($dot_us_file_url);
    if(!$csvFile){
        exit;
    }
    $filedata = [];
    foreach ($csvFile as $line) {
        $filedata[] = str_getcsv($line);
    }
    // echo '<pre>';
    // print_r($filedata);
    // echo '</pre>';
    echo '<h3>File Read</h3>';
    echo '<table class="wp-list-table striped table-view-list">';
    foreach($filedata as $line){
        echo '<tr>';
            //$items = explode(";",$line[0]);
            foreach($line as $item){
                echo '<td>'.$item.'</td>';
            }
        echo '</tr>';
    }
    echo '</table>';

    echo '<hr>';
}


?>