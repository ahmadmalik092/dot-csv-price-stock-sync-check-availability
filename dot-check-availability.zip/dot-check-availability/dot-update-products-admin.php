<?php
//add dot_stock_update_last and dot_stock_update_next fields


// {} = []
// get an option
$dot_options = get_option('dot_cu_update_options');
if($dot_options)
    $dot_options = json_decode($dot_options, true);


$dot_landingpages_url = isset($dot_options ['dot_landingpages_url']) ? $dot_options ['dot_landingpages_url']: ''; //areas(areaid,landingpage) file
$dot_addresses_url = isset($dot_options ['dot_addresses_url']) ? $dot_options ['dot_addresses_url']: ''; //address(areaid,landingpage) file

//$dot_us_match_product_attr = isset($dot_options['dot_us_match_product_attr']) ? $dot_options['dot_us_match_product_attr']: '';
//$dot_us_match_csv_col = isset($dot_options['dot_us_match_csv_col']) ? $dot_options['dot_us_match_csv_col']: '';

$dot_form_id = isset($dot_options['dot_form_id']) ? $dot_options['dot_form_id']: '';
// $dot_street_field_id = isset($dot_options['dot_street_field_id']) ? $dot_options['dot_street_field_id']: '';
// $dot_houseno_field_id = isset($dot_options['dot_houseno_field_id']) ? $dot_options['dot_houseno_field_id']: '';
// $dot_zip_field_id = isset($dot_options['dot_zip_field_id']) ? $dot_options['dot_zip_field_id']: '';
// $dot_town_field_id = isset($dot_options['dot_town_field_id']) ? $dot_options['dot_town_field_id']: '';

?>


<script type="text/javascript">
    var ajax_url = "<?php echo admin_url('admin-ajax.php'); ?>";
</script>

<h2>Check Settings</h2>
<p>Configure How do you want the users to check availability...</p>

<hr>
<h3>Landing Pages File URL</h3>
<p>File that includes AreaID and Landing Page.</p>
<input type="url" id="dot_landingpages_url" class="dot_update_stock" name="dot_landingpages_url" value="<?php echo $dot_landingpages_url; ?>">
<br><br>

<h3>Addresses File URL</h3>
<p>File that includes House#, Street, Zip, and Town.</p>
<input type="url" id="dot_addresses_url" class="dot_update_stock" name="dot_addresses_url" value="<?php echo $dot_addresses_url; ?>">
<br><br>

<h3>Form ID</h3>
<p>Form that user will fill to check availability.</p>
<input type="text" id="dot_form_id" class="dot_update_stock" name="dot_form_id" value="<?php echo $dot_form_id; ?>">
<br><br>
<button id="dot_settings_save">Save Settings</button>
<p id="dot_status"></p>
<hr>
<?php
$dot_landingpages_url = "https://shahibazar.online/wp-content/uploads/2021/10/adresspruefung_areas.csv";
if(isset($dot_landingpages_url)){
    $csvFile = file($dot_landingpages_url);
    if(!$csvFile){
        exit;
    }
    $filedata = [];
    foreach ($csvFile as $line) {
        $filedata[] = str_getcsv($line,';');
    }
    

    echo '<h3>Landing Pages File Read</h3>';
    echo '<table class="wp-list-table striped table-view-list">';
    foreach($filedata as $row){
        echo '<tr>';
            foreach($row as $col){
                echo '<td style="padding:2px 8px;">'.$col.'</td>';
            }
        echo '</tr>';
    }
    echo '</table>';
}

echo '<hr>';

$dot_landingpages_url = "https://shahibazar.online/wp-content/uploads/2021/10/adresspruefung_adresses.csv";
if(isset($dot_landingpages_url)){
    $csvFile = file($dot_landingpages_url);
    if(!$csvFile){
        exit;
    }
    $filedata = [];
    foreach ($csvFile as $line) {
        $filedata[] = str_getcsv($line,';');
    }
    

    echo '<h3>Addresses File Read</h3>';
    echo '<table class="wp-list-table striped table-view-list">';
    foreach($filedata as $row){
        echo '<tr>';
            foreach($row as $col){
                echo '<td style="padding:2px 8px;">'.$col.'</td>';
            }
        echo '</tr>';
    }
    echo '</table>';
}

echo '<hr>';

function dot_print($something){
    echo '<pre>';
    print_r($something);
    echo '</pre>';
}





?>